import express from "express";
// import { getTvShows, getShow } from "../tmdb-api";
import tvModel from "./tvModel";

const router = express.Router();

router.get("/" , (req, res, next) => {
   tvModel.find().then(tv => res.status(200).send(tv)).catch(next);
});

router.get("/:id" , (req, res, next) => {
   const id = parseInt(req.params.id);
   tvModel.findByShowId(id).then(tv => res.status(200).send(tv)).catch(next);
});

export default router;