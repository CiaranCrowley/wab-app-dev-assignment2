/* eslint-disable no-unused-vars */
import express from "express";
import { getMovieReviews } from "../tmdb-api";
import movieModel from "./movieModel";
import upcomingModel from "./upcomingModel";
import popularModel from "./popularModel";

const router = express.Router();

router.get('/', (req, res, next) => {
	movieModel.find().then(movies => res.status(200).send(movies)).catch(next);
});

router.get('/:id', (req, res, next) => {
	const id = parseInt(req.params.id);
	movieModel.findByMovieDBId(id).then(movie => res.status(200).send(movie)).catch(next);
});

router.get("/:id/reviews", (req, res, next) => {
	const id = parseInt(req.params.id);
	getMovieReviews(id)
	.then((reviews) => res.status(200).send(reviews))
	.catch((error) => next(error));
});

router.get("/upcoming", (req, res, next) => {  //Upcoming returns the same results as discover movies, but TMDB returns different results
	upcomingModel.find().then(upcoming => res.status(200).send(upcoming)).catch(next);
});

router.get("/popular", (req, res, next) => {  //According to TMDB, discover movies and popular movies currently return the same results
	popularModel.find().then(popular => res.status(200).send(popular)).catch(next);
});

export default router;
