import mongoose from 'mongoose';

const Schema = mongoose.Schema;

const PeopleSchema = new Schema({
   id: { type: Number, required: true, unique: true },
   profile_path: { type: String },
   name: { type: String },
   known_for_department: { type: String },
   gender: { type: Number },
   popularity: { type: Number },
 });
 
 PeopleSchema.statics.findByPersonId = function (id) {
    return this.findOne({ id: id });
  };
  
 export default mongoose.model('People', PeopleSchema);