/* eslint-disable no-unused-vars */
import express from "express";
// import { getPeople, getPerson } from "../tmdb-api";
import peopleModel from "./peopleModel";

const router = express.Router();

router.get("/", (req, res, next) => {
   peopleModel.find().then(person => res.status(200).send(person)).catch(next);
});

router.get("/:id", (req, res, next) => {
   const id = parseInt(req.params.id);
   peopleModel.findByPersonId(id).then(person => res.status(200).send(person)).catch(next);
});

export default router;