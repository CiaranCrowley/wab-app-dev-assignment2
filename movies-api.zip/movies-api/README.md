# Assignment 2 - Agile Software Practice.

Name: Ciarán Crowley

## Target Web API.

...... Document the Web API that is the target for this assignment's CI/CD pipeline. Include the API's endpoints and any other features relevant to the creation of a suitable pipeline, e.g.

<h2>MOVIES Endpoint</h2>

+ Get /api/movies - returns an array of movie objects when authenticated.
+ Get /api/movies - returns no movie objects when not authenticated.
+ Get /api/movies/:id - returns detailed information on a specific movie when authenticated.
+ Get /api/movies/:id - returns nothing when the id is invalid and when authenticated.
+ Get /api/movies/:id - returns detailed information on a specific movie when not authenticated.
+ Get /api/movies/:id - returns nothing when the id is invalid and when not authenticated.
+ Get /api/upcoming - returns an array of upcoming movie objects when authenticated.
+ Get /api/upcoming - returns an array of upcoming movie objects when not authenticated.
+ Get /api/popular - returns an array of popular movie objects when authenticated.
+ Get /api/popular - returns an array of popular movie objects when not authenticated.

<h2>TV Endpoint</h2>

+ Get /api/tv - returns an array of tv objects when authenticated.
+ Get /api/tv - returns no tv objects when not authenticated.
+ Get /api/tv/:id - returns detailed information on a specific tv show when authenticated.
+ Get /api/tv/:id - returns nothing when the id is invalid and when authenticated.
+ Get /api/tv/:id - returns detailed information on a specific tv show when not authenticated.
+ Get /api/tv/:id - returns nothing when the id is invalid and when not authenticated.

<h2>People Endpoint</h2>

+ Get /api/people - returns an array of people objects when authenticated.
+ Get /api/people - returns no people objects when not authenticated.
+ Get /api/people/:id - returns detailed information on a specific actor when authenticated.
+ Get /api/people/:id - returns nothing when the id is invalid and when authenticated.
+ Get /api/people/:id - returns detailed information on a actor show when not authenticated.
+ Get /api/people/:id - returns nothing when the id is invalid and when not authenticated.

## Error/Exception Testing.

.... From the list of endpoints above, specify those that have error/exceptional test cases in your test code, the relevant test file and the nature of the test case(s), e.g.

+ Get /api/movies - test that when the user is not authenticated, no movies are returned.
+ Get /api/upcoming - test that when the user is not authenticated, no upcoming movies are returned.
+ Get /api/popular - test that when the user is not authenticated, no popular are returned.
+ Get /api/tv - test that when the user is not authenticated, no tv shows are returned.
+ Get /api/people - test that when the user is not authenticated, no actors are returned.
## Continuous Delivery/Deployment.

..... Specify the URLs for the staging and production deployments of your web API, e.g.

+ https://movies-api-staging-ciaran.herokuapp.com - Staging deployment
+ https://movies-api-production-ciaran.herokuapp.com - Production

+ Staging app overview 

![stagingApp][/pulic/staging.png]

+ Production app overview 

![productionApp][/pulic/production.png]

## Feature Flags (If relevant)

... Specify the feature(s) in your web API that is/are controlled by a feature flag(s). Mention the source code files that contain the Optimizerly code that implement the flags. Show screenshots (with appropriate captions) from your Optimizely account that prove you successfully configured the flags.


[stagingapp]: ./img/stagingapp.png