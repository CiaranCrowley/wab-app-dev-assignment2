/* eslint-disable no-undef */
import chai from "chai";
import request from "supertest";

const expect = chai.expect;


let api;
// let token = "eyJhbGciOiJIUzI1NiJ9.dXNlcjE.FmYria8wq0aFDHnzYWhKQrhF5BkJbFNN1PqNyNQ7V4M";
let token;

const sampleMovie = {
  id: 590706,
  title: "Jiu Jitsu",
};


describe("Movies endpoint", () => {

  beforeEach(async () => {
     try {
       api = require("../../../../index");
    } catch (err) {
      console.error(`failed to Load user Data: ${err}`);
    }
  });

  afterEach(() => {
    api.close(); // Release PORT 8080
    delete require.cache[require.resolve("../../../../index")];
    return true;
  });


  describe("GET /movies when authenticated", () => {
    it("should return 20 movies and a status 200", () => {
      request(api)
      .get("/api/movies")
      .set('Authorization', 'Bearer ' + token)
      .set("Accept", "application/json")
      .expect("Content-Type", /json/)
      .expect(200)
      .then((res) => {
        expect(res.body).to.be.a("array");
        expect(res.body.length).to.equal(20);
        done();
      });
    });
  });

  describe("GET/movies when not authencticated", () => {
    it("should not return any movies", () => {
      request(api)
      .get("/api/movies")
      .set("Accept", "application/json")
      .expect("Content-Type", /json/)
      .then(res => {
        expect(res.body).to.be.empty;
      });
    });
  });

  describe("GET /movies/:id when authenticated", () => {
    describe("when the id is valid", () => {
      it("should return the matching movie", () => {
        request(api)
          .get(`/api/movies/${sampleMovie.id}`)
          .set('Authorization', 'Bearer ' + token)
          .set("Accept", "application/json")
          .expect("Content-Type", /json/)
          .expect(200)
          .then((res) => {
            expect(res.body).to.have.property("title", sampleMovie.title);
          });
      });
    });

    describe("when the id is invalid", () => {
      it("should return the NOT found message", () => {
        request(api)
          .get("/api/movies/xxx")
          .set('Authorization', 'Bearer ' + token)
          .set("Accept", "application/json")
          .expect("Content-Type", /json/)
          .expect({
            success: false,
            status_code: 34,
            status_message: "The resource you requested could not be found.",
          });
      });
    });
  });

  describe("GET /movies/:id when not authenticated", () => {
    it("should not return any movies", () => {
      request(api)
      .get(`/api/movies/${sampleMovie.id}`)
      .set("Accept", "application/json")
      .expect("Content-Type", /json/)
      .then((res) => {
        expect(res.body).to.be.empty;
      });
    });
  });

  describe("GET upcoming movies when authenticated ", () => {
    it("should return 20 upcoming movies and a status 200", () => {
      request(api)
        .get("/api/upcoming")
        .set('Authorization', 'Bearer ' + token)
        .set("Accept", "application/json")
        .expect("Content-Type", /json/)
        .expect(200)
        .end((res) => {
          // expect(res.body).to.be.a("array");
          // expect(res.body.length).to.equal(20);
          // done();
        });
    });
  });

  describe("GET upcoming movies when not authenticated ", () => {
    it("should not return any upcoming movies", () => {
      request(api)
        .get("/api/upcoming")
        .set("Accept", "application/json")
        .expect("Content-Type", /json/)
        .then(res => {
          expect(res.body).to.be.empty;
          done();
      });
    });
  });

  describe("GET popular movies when authenticated", () => {
    it("should return 20 popular movies and a status 200", () => {
      request(api)
        .get("/api/popular")
        .set('Authorization', 'Bearer ' + token)
        .set("Accept", "application/json")
        .expect("Content-Type", /json/)
        .expect(200)
        .end((res) => {
          // expect(res.body).to.be.a("array");
          // expect(res.body.length).to.equal(20);
          // done();
        });
    });
  });

  describe("GET popular movies when not authenticated ", () => {
    it("should not return any popular movies", () => {
      request(api)
        .get("/api/popular")
        .set("Accept", "application/json")
        .expect("Content-Type", /json/)
        .then(res => {
          expect(res.body).to.be.empty;
          done();
      });
    });
  });
});
