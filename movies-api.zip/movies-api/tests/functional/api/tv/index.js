/* eslint-disable no-unused-vars */
/* eslint-disable no-undef */
import chai from "chai";
import request from "supertest";

const expect = chai.expect;

let api;
let token = "eyJhbGciOiJIUzI1NiJ9.dXNlcjE.FmYria8wq0aFDHnzYWhKQrhF5BkJbFNN1PqNyNQ7V4M";

const sampleShow = {
   id: 77169,
   original_name: "Cobra Kai",
};

describe("Tv endpoint", () => {
   beforeEach(async () => {
      try {
         api = require("../../../../index");
      } catch (err) {
         console.error(`failed to Load user data: ${err}`);
      }
   });

   afterEach(() => {
      api.close(); //Release Port 8080
      delete require.cache[require.resolve("../../../../index")];
   });

   describe("GET /tv when authenticated", () => {
      it("should return 20 tv shows and a status 200", () => {
         request(api)
         .get("/api/tv")
         .set('Authorization', 'Bearer ' + token)
         .set("Accept", "application/json")
         .expect("Content-Type", /json/)
         .expect(200)
         .then((res) => {
            expect(res.body).to.be.a("array");
            expect(res.body.length).to.equal(20);
            done();
         });
      });
   });

   describe("GET /tv when not authenticated", () => {
      it("should not return any tv shows", () => {
         request(api)
         .get("/api/tv")
         .set("Accept", "application/json")
         .expect("Content-Type", /json/)
         .then((res) => {
            expect(res.body).to.be.empty;
         });
      });
   });

   describe("GET /tv/:id when authenticated", () => {
      describe("when the id is valid", () => {
         it("should return the matching tv show", () => {
            request(api)
            .get(`/api/tv/${sampleShow.id}`)
            .set('Authorization', 'Bearer ' + token)
            .set("Accept", "application/json")
            .expect("Content-Type", /json/)
            .expect(200)
            .then((res) => {
               expect(res.body).to.have.property("name", sampleShow.original_name);
            });
         });
      });

      describe("when the id is invalid", () => {
         it("should return NOT found message", () => {request(api)
            .get("/api/tv/xxx")
            .set('Authorization', 'Bearer ' + token)
            .set("Accept", "application/json")
            .expect("Content-Type", /json/)
            .expect({
              success: false,
              status_code: 34,
              status_message: "The resource you requested could not be found.",
            });
         });
      });
   });

   describe("GET /tv/:id when not authenticated", () => {
      describe("when the id is valid", () => {
         it("should return the matching tv show", () => {
            request(api)
            .get(`/api/tv/${sampleShow.id}`)
            .set("Accept", "application/json")
            .expect("Content-Type", /json/)
            .expect(200)
            .then((res) => {
               expect(res.body).to.be.empty;
            });
         });
      });
   });

   // Add a Favourite Tv Shows
   // describe("POST and check favourite Shows", () => {
   //    it("should add The Mandalorian as a favourite and check that it has been added", () => {
   //       return request(api)
   //       .post("/api/users/user1/favouriteShows")
   //       .send({
   //          "id": 82856,
   //          "title": "The Mandalorian"
   //       })
   //       .expect(201)
   //       .then(
   //          request(api)
   //          .get("api/users/user1/favouriteShows")
   //          .set("Accept", "application/json")
   //          .expect("Content-Type", /json/)
   //          .expect(200)
   //          .then((res) => {
   //             expect(res.body).to.have.property("title", sampleShow.original_name);
   //          })
   //       );
   //    });
   // });
});