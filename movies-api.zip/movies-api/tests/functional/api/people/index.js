/* eslint-disable no-unused-vars */
/* eslint-disable no-undef */
import chai from "chai";
import request from "supertest";

const expect = chai.expect;

let api;
let token = "eyJhbGciOiJIUzI1NiJ9.dXNlcjE.FmYria8wq0aFDHnzYWhKQrhF5BkJbFNN1PqNyNQ7V4M";

const sampleActor = {
	id: 90633,
	name: "Gal Gadot"
};

describe("People Endpoint", () => {
	beforeEach(async () => {
		try {
			api = require("../../../../index");
		} catch (err) {
			console.error(`failed to Load user data: ${err}`);
		}
	});
	
	afterEach(() => {
		api.close(); //Release Pport 8080
		delete require.cache[require.resolve("../../../../index")];
	});

	describe("GET /people when authenticated", () => {
		it("should return the details of 2 actors and a status 200", () => {
			request(api)
			.get("/api/people")
			.set('Authorization', 'Bearer ' + token)
			.set("Accept", "application/json")
         .expect("Content-Type", /json/)
			.expect(200)
			.then((res) => {
            expect(res.body).to.be.a("array");
            expect(res.body.length).to.equal(20);
            done();
         });
		});
	});

	describe("GET /people when not authenticated", () => {
		it("should not return the details of any actors", () => {
			request(api)
			.get("/api/people")
			.set("Accept", "application/json")
         .expect("Content-Type", /json/)
			.expect(200)
			.then((res) => {
            expect(res.body).to.be.empty;
         });
		});
	});

	describe("GET /people/:id when authenticated", () => {
		describe("when the id is valid", () => {
			it("should return the matching person", () => {
				request(api)
				.get(`/api/people/${sampleActor.id}`)
            .set('Authorization', 'Bearer ' + token)
				.expect("Content-Type", /json/)
				.expect(200)
				.then((res) => {
					expect(res.body).to.have.property("name", sampleActor.name);
				});
			});
		});
	});

	describe("when the id is invalid and authenticated", () => {
		it("should retuen NOT found message", () => {request(api)
			.get("/api/people/xxxx")
			.set('Authorization', 'Bearer ' + token)
			.set("Accept", "application/json")
			.expect("Content-Type", /json/)
			.expect({
				success: false,
				status_code: 34,
				status_message: "The resource you requested could not be found."
			});
		});
	});

	describe("GET /people/:id when not authenticated", () => {
		describe("when the id is valid", () => {
			it("should return the matching person", () => {
				request(api)
				.get(`/api/people/${sampleActor.id}`)
				.expect("Content-Type", /json/)
				.expect(200)
				.then((res) => {
					expect(res.body).to.be.empty;
				});
			});
		});
	});

	//Add a favourite Actor
	// describe("POST and check favoururite Actors", () => {
	// 	it("should add Gal Gadot as a favourite actor and check that she has been added", () => {
	// 		return request(api)
	// 		.post("/api/users/user1/favouriteActors")
	// 		.send({
	// 			"id": 90633,
	// 			"name": "Gal Gadot"
	// 		})
	// 		.expect(201)
	// 		.then(
	// 			request(api)
	// 			.get("/api/users/user1/favouriteActors")
	// 			.set("Accept", "application/json")
	// 			.expect("Content-Type", /json/)
	// 			.expect(200)
	// 			.then((res) => {
	// 				expect(res.body).to.have.property("name", sampleActor.name);
	// 			})
	// 		);
	// 	});
	// });
});