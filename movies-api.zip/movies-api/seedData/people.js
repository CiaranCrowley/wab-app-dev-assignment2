export const people = [
      {
         "gender": 1,
         "id": 90633,
         "known_for_department": "Acting",
         "name": "Gal Gadot",
         "popularity": 51.346,
         "profile_path": "/9dlMlZiLtFr7v1yJ6Yy7Xp1jaXB.jpg"
      },
      {
         "gender": 1,
         "id": 4494,
         "known_for_department": "Acting",
         "name": "Lisa Ann Walter",
         "popularity": 43.515,
         "profile_path": "/3xeMzT5zOC0UM9DgHne3oGZmf1R.jpg"
      },
      {
         "gender": 1,
         "id": 1245,
         "known_for_department": "Acting",
         "name": "Scarlett Johansson",
         "popularity": 	42.819,
         "profile_path": "/6NsMbJXRlDZuDzatN2akFdGuTvx.jpg"
      },
      {
         "gender": 2,
         "id": 31,
         "known_for_department": "Acting",
         "name": "Tom Hanks",
         "popularity": 31.424,
         "profile_path": "/zVyoR2ZNiVGymjZK4MMJHIdpxoW.jpg"
      },
      {
         "gender": 1,
         "id": 976,
         "known_for_department": "Acting",
         "name": "Jason Statham",
         "popularity": 28.298,
         "profile_path": "/lldeQ91GwIVff43JBrpdbAAeYWj.jpg"
      },
      {
         "gender": 1,
         "id": 1397778,
         "known_for_department": "Acting",
         "name": "Anya Taylor-Joy",
         "popularity": 30.437,
         "profile_path": "/1zA5GuTcciupj4PsNoV2YemB0Wm.jpg"
      }

];