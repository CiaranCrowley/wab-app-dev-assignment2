import loglevel from 'loglevel';
import userModel from '../api/users/userModel';
import movieModel from '../api/movies/movieModel';
import upcomingModel from '../api/movies/upcomingModel';
import popularModel from '../api/movies/popularModel';
import tvModel from '../api/tv/tvModel';
import peopleModel from '../api/people/peopleModel';
import {movies} from './movies.js';
import {upcomingMovies} from './upcomingMovies.js';
import {popularMovies} from './popularMovies.js';
import {tvShows} from './tvShows.js';
import {people} from './people.js';

const users = [
  {
    'username': 'user1',
    'password': 'test1',
  },
  {
    'username': 'user2',
    'password': 'test2',
  },
];

// deletes all user documents in collection and inserts test data
export async function loadUsers() {
  loglevel.info('load user Data');
  try {
    await userModel.deleteMany();
    // await userModel.collection.insertMany(users);
    await users.forEach(user => userModel.create(user));
    loglevel.info(`${users.length} users were successfully stored.`);
  } catch (err) {
    console.error(`failed to Load user Data: ${err}`);
  }
}

// deletes all movies documents in collection and inserts test data
export async function loadMovies() {
  loglevel.info('load seed data');
  loglevel.info(movies.length);
  try {
    await movieModel.deleteMany();
    await movieModel.collection.insertMany(movies);
    loglevel.info(`${movies.length} movies were successfully stored.`);
  } catch (err) {
    console.error(`failed to Load movie Data: ${err}`);
  }
}

export async function loadUpcomingMovies() {
  loglevel.info('load seed data');
  loglevel.info(upcomingMovies.length);
  try {
    await upcomingModel.deleteMany();
    await upcomingModel.collection.insertMany(upcomingMovies);
    loglevel.info(`${upcomingMovies.length} upcoming movies were successfully stored.`);
  } catch (err) {
    console.error(`failed to Load movie Data: ${err}`);
  }
}

export async function loadPopularMovies() {
  loglevel.info('load seed data');
  loglevel.info(popularMovies.length);
  try {
    await popularModel.deleteMany();
    await popularModel.collection.insertMany(popularMovies);
    loglevel.info(`${popularMovies.length} popular movies were successfully stored.`);
  } catch (err) {
    console.error(`failed to Load movie Data: ${err}`);
  }
}

export async function loadTvShows() {
  loglevel.info('load seed data');
  loglevel.info(tvShows.length);
  try {
    await tvModel.deleteMany();
    await tvModel.collection.insertMany(tvShows);
    loglevel.info(`${tvShows.length} tv shows were successfully stored.`);
  } catch (err) {
    console.error(`failed to Load tv show Data: ${err}`);
  }
}

export async function loadPeople() {
  loglevel.info('load seed data');
  loglevel.info(people.length);
  try {
    await peopleModel.deleteMany();
    await peopleModel.collection.insertMany(people);
    loglevel.info(`${people.length} people were successfully stored.`);
  } catch (err) {
    console.error(`failed to Load people Data: ${err}`);
  }
}